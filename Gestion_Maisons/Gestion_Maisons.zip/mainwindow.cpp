
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "SeConnecter.h"
#include <QMessageBox>
#include <QDebug>


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , table(new table_hachage())
{
    ui->setupUi(this);
    setWindowTitle("Gestion Maison");

    // Attempt to connect to the database
    if (NotreConnection()) {
        QMessageBox::information(this, "Connexion", "Connexion à la base de données réussie !");
        // Load data from database and update display
        table->charger();
        on_displayButton_clicked();
    } else {
        QMessageBox::critical(this, "Erreur", "Échec de la connexion à la base de données !");
    }

    // Connect buttons to slots
    connect(ui->addButton, &QPushButton::clicked, this, &MainWindow::on_addButton_clicked);
    connect(ui->getButton, &QPushButton::clicked, this, &MainWindow::on_getButton_clicked);
    connect(ui->deleteButton, &QPushButton::clicked, this, &MainWindow::on_deleteButton_clicked);
    connect(ui->displayButton, &QPushButton::clicked, this, &MainWindow::on_displayButton_clicked);
    connect(ui->loadButton, &QPushButton::clicked, this, &MainWindow::on_loadButton_clicked);
    connect(ui->saveButton, &QPushButton::clicked, this, &MainWindow::on_saveButton_clicked);
    connect(ui->clearButton, &QPushButton::clicked, this, &MainWindow::on_clearButton_clicked);

    // Initialize the hash table
    table->setHachage_actuelle(1); // Use f1 as default hash function
}

MainWindow::~MainWindow()
{
    delete table;
    delete ui;
}

void MainWindow::on_addButton_clicked()
{
    QString id = ui->idLineEdit->text();
    QString type = ui->typeLineEdit->text();
    QString standing = ui->standingLineEdit->text();
    int chambres = ui->chambresSpinBox->value();
    int toilettes = ui->toilettesSpinBox->value();
    QString modele = ui->modeleLineEdit->text();
    QString description = ui->descriptionTextEdit->toPlainText();
    QString photosStr = ui->photosLineEdit->text();

    if (id.isEmpty() || type.isEmpty() || standing.isEmpty() || modele.isEmpty()) {
        QMessageBox::warning(this, "Erreur de saisie", "Veuillez remplir tous les champs requis (Clé, Type, Standing, Modèle).");
        return;
    }

    QVector<QString> photos;
    if (!photosStr.isEmpty()) {
        QStringList photosList = photosStr.split(",");
        for (const QString &photo : photosList) {
            photos.append(photo.trimmed());
        }
    }

    VALEUR val = creerVal(type, standing,chambres, toilettes,modele, description, photos);
    table->inserer(id, val);
    QMessageBox::information(this, "Succès", "Maison ajoutée avec succès !");
    clearInputs();
    on_displayButton_clicked(); // Update display after adding
}

void MainWindow::on_getButton_clicked()
{
    QString id = ui->idLineEdit->text();
    if (id.isEmpty()) {
        QMessageBox::warning(this, "Erreur de saisie", "Veuillez entrer une clé.");
        return;
    }

    VALEUR val = table->get(id);
    if (val.type.isEmpty()) {
        QMessageBox::information(this, "Non trouvé", "Aucune maison trouvée avec la clé : " + id);
        return;
    }

    ui->typeLineEdit->setText(val.type);
    ui->standingLineEdit->setText(val.standing);
    ui->modeleLineEdit->setText(val.modele);
    ui->chambresSpinBox->setValue(val.nombre_de_chambre);
    ui->toilettesSpinBox->setValue(val.nombre_de_toilettes);
    ui->photosLineEdit->setText(val.photos.toList().join(", "));
    ui->descriptionTextEdit->setPlainText(val.description);
}

void MainWindow::on_deleteButton_clicked()
{
    QString id = ui->idLineEdit->text();
    if (id.isEmpty()) {
        QMessageBox::warning(this, "Erreur de saisie", "Veuillez entrer une clé.");
        return;
    }

    if (table->contient(id)) {
        table->supprimer(id);
        QMessageBox::information(this, "Succès", "Maison avec la clé " + id + " supprimée avec succès !");
        clearInputs();
        on_displayButton_clicked(); // Update display after deleting
    } else {
        QMessageBox::information(this, "Non trouvé", "Aucune maison trouvée avec la clé : " + id);
    }
}

void MainWindow::on_displayButton_clicked()
{
    QString output;
    QTextStream stream(&output);
    int houseCount = 0;
    for (int j = 0; j < Nmax; j++) {
        MAISON *current = table->getMaisonAtIndex(j);
        while (current) {
            stream << "Clé : " << current->cle << "\n";
            stream << "Type : " << current->valeur.type << "\n";
            stream << "Standing : " << current->valeur.standing << "\n";
            stream << "Modèle : " << current->valeur.modele << "\n";
            stream << "Nombre de chambres : " << current->valeur.nombre_de_chambre << "\n";
            stream << "Nombre de toilettes : " << current->valeur.nombre_de_toilettes << "\n";
            stream << "Description : " << current->valeur.description << "\n";
            stream << "Nombre de photos : " << current->valeur.photos.size() << "\n";
            stream << "-----------------------------------\n";
            current = current->suivant;
            houseCount++;
        }
    }
    ui->displayTextEdit->setPlainText(output);
    qDebug() << "Affichage : " << houseCount << " maison(s) affichée(s)";
}

void MainWindow::on_loadButton_clicked()
{
    table->charger();
    QMessageBox::information(this, "Succès", "Données chargées depuis la base de données !");
    on_displayButton_clicked(); // Ensure display is updated after loading
}

void MainWindow::on_saveButton_clicked()
{
    table->sauvegarder();
    QMessageBox::information(this, "Succès", "Données enregistrées dans la base de données !");
}

void MainWindow::on_clearButton_clicked()
{
    table->vider();
    QMessageBox::information(this, "Succès", "Tableau de hachage vidé !");
    ui->displayTextEdit->clear();
    clearInputs();
}

void MainWindow::clearInputs()
{
    ui->idLineEdit->clear();
    ui->typeLineEdit->clear();
    ui->standingLineEdit->clear();
    ui->modeleLineEdit->clear();
    ui->chambresSpinBox->setValue(0);
    ui->toilettesSpinBox->setValue(0);
    ui->photosLineEdit->clear();
    ui->descriptionTextEdit->clear();
}
