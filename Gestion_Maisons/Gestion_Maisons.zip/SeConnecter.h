#ifndef SE_CONNECTER_H
#define SE_CONNECTER_H

#include "QSqlDatabase" // En-tête pour QSqlDatabase
#include <QDebug>       // En-tête pour qDebug
#include <QSqlError>
#include <QSqlQuery>
#include <QMessageBox>
bool NotreConnection();

#endif // SE_CONNECTER_H

